       function confirm(){
                    var Confirm = document.getElementById("confirm-price").value;
                    var person;
                    person=6;
                    var fill ;
                    fill=document.getElementsByClassName("present-input").value;
                    if(Confirm == "Pes2015jaber" )
                    document.getElementById("present-step3-p").innerHTML="تایید شد.";
                    document.getElementById("present-step3-p").style.color="green";
                    document.getElementById("present-step3-p").style.fontWeight="bold";
                    document.getElementById("present-step3-p").style.textAlign="center";
                }
                function changecode(){
                    var data;
                    data = document.getElementById("code-input").value;
                    if(data<=25){
                    document.getElementById("pcode").innerHTML="کد 35/مجاز است";
                    document.getElementById("pcode").style.backgroundColor="green";

                    }
                    else if(data>25 && data<=30){
                        document.getElementById("pcode").innerHTML="کد 25/مجاز است";
                        document.getElementById("pcode").style.backgroundColor="green";

                    }
                    else if(data>30 && data<=35){
                        document.getElementById("pcode").innerHTML="کد 15/احتیاط ";
                        document.getElementById("pcode").style.backgroundColor="orange";

                    }
                    else if(data>35 && data<=50){
                        document.getElementById("pcode").innerHTML="کد 05/مجاز نیست";
                        document.getElementById("pcode").style.backgroundColor="red";

                    }
                    else{
                    document.getElementById("pcode").innerHTML="کد 03/مجاز نیست";
                    document.getElementById("pcode").style.backgroundColor="black";
                    }
                }
                //this is related to .car-reservior-service//

    var countDownMin = new Date().getMinutes();   
    function car_service(){
        window.open("car-service.html","_self");
    }     
    
                
                